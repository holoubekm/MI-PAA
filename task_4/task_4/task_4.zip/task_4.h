#ifndef __TASK_4__
#define __TASK_4__

#endif
