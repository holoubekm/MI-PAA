#pragma once

#include <cstdio>
#include <cstdlib>
#include <sstream>
#include <iostream>
#include <fstream>
#include <climits>
#include <limits>
#include <vector>
#include <set>
#include <random>
#include <cmath>
#include <algorithm>
#include <string>

double GetCPUTime();
double GetWallTime();
