#include "stdafx.h"
#include "item.h"


Item::Item(double pWeight, double pPrice) {
	mWeight = pWeight;
	mPrice = pPrice;
}


Item::~Item()
{
}
