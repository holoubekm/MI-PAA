#ifndef __ITEM__
#define __ITEM__

class Item
{
public:
	Item(double pWeight, double pPrice);
	~Item();


public:
	double mWeight;
	double mPrice;
};

#endif
